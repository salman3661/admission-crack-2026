# START HERE — সব এক জায়গায়

**আজ ১৮ নভেম্বর ২০২৬ · DU Ka: ১২ ডিসে (২৫ দিন) · MAT: ১৮ ডিসে (৩১ দিন)**

---

## ⚡ আজকের ৩ টা কাজ (৩০ মিনিট)

```
১. 1-now-exam-prep/roadmap-25-din.md        → পড়ো (এটাই তোমার মূল প্ল্যান)
২. 1-now-exam-prep/mock-tracker.csv         → Google Sheet-এ খোলো
   1-now-exam-prep/error-log-template.csv    → আলাদা sheet-এ খোলো
৩. 1-now-exam-prep/20-80-FOCUS-only.csv     → ছাপে রাখো — এটাই তোমার পড়ার তালিকা
```

**তারপর আজই ২টি focus chapter পড়া শুরু করো।** বাকি সব ধাপ নিচে দেওয়া আছে।

---

## 📁 এই প্যাকেজে কী আছে

### `1-now-exam-prep/` — এখনই দরকার (প্রায়োরিটি অনুযায়ী)

| ফাইল | কী | কখন |
|---|---|---|
| **`roadmap-25-din.md`** | ★ ২৫ দিনের পুরো ক্যালেন্ডার, coaching exam-র রিচুয়াল, ৭টি rule, written-এর প্ল্যান, exam-hall tactics | আজ পড়ো |
| **`score-plan-78-80.md`** | ৭৮-৮০+ এর গণিত (MCQ 48-50 + written 28-30), ২৫ দিনের phase breakdown | আজ পড়ো |
| **`mock-tracker.csv`** | ৭টি coaching exam-এর score sheet — প্রতিটি mock-এর পরে ফিল করো | আজ খোলো |
| **`error-log-template.csv`** | ★ তোমার সবচেয়ে বড় সম্পদ — প্রতিটি ভুলের লগ | আজ খোলো |
| **`20-80-FOCUS-only.csv`** | ৫২টি focus chapter (exam role + বছর-সংখ্যা সহ) | আজ ছাপো |
| `master-set-DU-KA-SET-A.tsv` | ৬০ প্রশ্ন — DU Ka-র exact structure (Phys 15 + Chem 15 + Math 15 + Bio 15) | Phase 1-2 |
| `master-set-DU-KA-SET-B.tsv` | ৬০ প্রশ্ন — দ্বিতীয় স্তর, A-র সাথে overlap ০ | Phase 2 |
| `master-set-DU-KA-SET-C.tsv` | ২৪ — wildcard + অন্য varsity (RU/CU/JU/GST)-এর material | Phase 4 |
| `master-set-MAT-SET-A.tsv` | ১০০ প্রশ্ন — MAT exact structure (Bio 30 + Chem 25 + Phys 20 + Eng 15 + GK 10) | Phase 1-2 |
| `master-set-MAT-SET-B.tsv` / `-C.tsv` | ১০০ / ৪০ | Phase 2 / 5 |
| `master-set-chapter-map.csv` | প্রতিটি chapter: predicted MCQ + কোন set-এ কয়টি + কত বছরে এসেছে | চার্ট চাইলে |
| `master-set-written-drill.csv` | ১৬টি লিখিত প্রশ্ন (written ৪০ নম্বরের drill) | প্রতিদিন ৪টি |
| `master-set-formula-cards.csv` | ৩৬৬ সূত্র কার্ড — written-এর জন্য মনে রাখার তালিকা | প্রতিদিন ৩০ মিনিট |
| `anki-deck.tsv` | ১,৪২৬ কার্ড — full ব্যাংক (Anki-তে import করো) | Phase 2 থেকে |
| `chapter-taxonomy.csv` | ১৪২টি chapter: slug + readable নাম + বছর + source | reference |
| `mega-type-frequency.csv` | ২৫৪ mega-type-এর frequency ও বছর-বিশ্লেষণ | reference |
| `predictor-truth.md` | "১০০% কেন না" — backtest-সহ সত্যি উত্তর | পড়া ভালো হয় |
| `sample-question.json` | ৫টি example row (schema বোঝার জন্য) | reference |

### `2-webapp-kit/` — অ্যাপ ঠিক করার জন্য (Phase 5-এর কাজ, এখন নয়)

| ফাইল | কী |
|---|---|
| `docs/00-MASTER-PROMPT.md` | ★ AI coding agent-কে দেওয়ার মূল প্রম্পট (নিজেই সম্পূর্ণ স্পেক) |
| `docs/01-DATA-SCHEMA.md` | schema + coaching paper যোগ করার নিয়ম |
| `docs/02-ENGINEERING-RULES.md` | ১৫টি rule, প্রতিটির কারণ + performance target |
| `docs/03-PREDICTOR-SPEC.md` | LEARN→PREDICT→SELECT + validation |
| `docs/04-FEATURES-SCOPE.md` | F1–F16 ফিচার, P0/P1/P2 ভাগ |
| `docs/05-ACCEPTANCE-CRITERIA.md` | agent-কে যাচাই করতে হবে |
| `scripts/` | prepare-data · validate-data · build-master-set · coverage-scorer (সব standalone) |
| `data/bank/` | ৫৫টি split ফাইল (regenerable — commit নয়) |

**Agent-কে কীভাবে দেবে:** `docs/00-MASTER-PROMPT.md`-এর পুরো ব্লক paste করো + এই ফোল্ডারটা দাও।
Script নিজেই deployed bundle থেকে data টেনে নেবে — তোমাকে কিছু upload করতে হবে না।

### `3-later-site-audit/` — এখন দরকার নেই, পরে পড়বে

| ফাইল | কী |
|---|---|
| `review-report.md` | সাইটের ২০টা বাগ/ঝুঁকি, severity tier সহ (critical 4 · medium 8 · low 8) |
| `improvement-roadmap.md` | ফিচার + SEO/ranking plan |
| `agent-brief.md` | যেকোনো agent-কে "আমার মতো" কাজ করানোর ব্রিফ |
| `fix-list.csv` | ৪৮টি ভাঙা প্রশ্ন + ১,১২৮ duplicate ID + count mismatch — ঠিক করার লিস্ট |

---

## 🗓 ক্যালেন্ডারে কী কখন

```
১৮–২২ নভে  Phase 1  ফোকাস ৫২ chapter পড়ো + SET-A
২৩–২৭ নভে  Phase 2  SET-A/B + প্রতিদিন ৪ লিখিত প্রশ্ন + error log
২৮ নভে    🎯 Paper Final   → সন্ধ্যায় analysis (top3 lossy chapter)
২৯ নভে    ওই ৩ chapter ঠিক করো
১ ডিসে    🎯 Subject Final → analysis
২–৫ ডিসে  🎯 Model Test 1, 2, 3 + SET-C wildcard
৫–৮ ডিসে  🎯 Model Test 4 + MAT SET-A (English+GK দুর্বলতা)
৯–১১ ডিসে 🎯 Model Test 5 → শুধু error log + formula card
১২ ডিসে   ★★★ DU KA EXAM ১১:০০–১২:৩০
১৩–১৭ ডিসে  MAT-নির্দিষ্ট ৬ দিন (English ১৫ + GK ১০ = ২৫ নম্বর)
১৮ ডিসে   ★★★ MAT EXAM
```

---

## ⚡ ৭টি NON-NEGOTIABLE

```
১. MCQ-তে P > 20% confident হলে attempt করো (EV = 1.25P − 0.25), নইলে বাদ দাও
২. MCQ ৪৫ সেকেন্ড/প্রশ্ন — timer ছাড়া mock কখনো নয়
৩. Written কখনো skip নয় (partial credit আছে, −0.25 নেই)
৪. Written সিলেবাস-স্টাইলে: সূত্র → কাজ → উত্তর
৫. Mock-এর analysis সাথে সাথে, পরের দিনে নয়
৬. M3-এর পরে নতুন content নেই
৭. Mock-এও ক্যালকুলেটর/ফোন নেই
```

---

## 🎯 মূল কৌশল: এক প্রস্তুতি, দুই পরীক্ষা

DU Ka-র Physics+Chem+Bio+Math আর MAT-র Physics+Chem+Bio — **~৭৫ নম্বর একই chapter থেকে**।
DU Ka-কে ৭৮-৮০ করলে MAT-এ ৭৫+ আসবেই (MAT-এ written নেই, তাই MCQ accuracy-ই সব)।

**written-ই আসল differentiator** — MCQ-তে −0.25 আছে, written-এ নেই। ৭৮-৮০ পেতে written-এ **২৮+** লাগবে।

---

## 🛠 নতুন coaching paper আসলে কী করবে

```
১. src/data/du_ka/model_test/model_test_03.json ফাইল বানাও
   (schema: 2-webapp-kit/docs/01-DATA-SCHEMA.md)
   প্রতিটি প্রশ্নে source_type + exam_date আবশ্যক
২. node scripts/validate-data.mjs src/data      → 0 error নিশ্চিত করো
৩. node scripts/build-master-set.mjs             → master set আবার তৈরি
```
**Coaching-এর Model Test = held-out validation set** — সেটা দিয়ে তোমার predictor-এর
সত্যিকারের accuracy মাপা যাবে। এটাই সবচেয়ে মূল্যবান সংখ্যা।

---

## ❌ যা করবে না (২৫ দিনে)

নতুন কোড · নতুন feature · অ্যাপের "98% Predict Repeat" label-এ trust ·
M3-এর পরে নতুন content · timer ছাড়া mock · written skip · mock-এর analysis বাদ দেওয়া

---

**শেষ কথা:** ব্যাংক নিয়ে আর সময় নষ্ট করো না — ওটা regenerable, আর সব ফাইল এখানেই আছে।
**এখন পড়া শুরু করো।** 📚
