# Admission Crack 2026 — অনলাইন ডেলিভারি রিভিউ

**সাইট:** https://admissionwebapp.vercel.app/#decks
**রিভিউ তারিখ:** 17 নভেম্বর 2026
**পদ্ধতি:** Deployed build (Vite bundle) সরাসরি ডাউনলোড করে স্ট্যাটিক অ্যানালাইসিস + headless Chromium (মোবাইল ভিউ) দিয়ে লাইভ টেস্ট। Firebase/RTDB/Storage REST API ও Vercel হেডার যাচাই করা হয়েছে।

---

## সারসংক্ষেপ

সাইটটা চালু আছে, ক্র্যাশ হয় না, কোনো JS এরর নেই — কিন্তু **ডেলিভারি করার আগে ৪টা বড় বিষয় ঠিক করা দরকার**: (১) কন্টেন্ট কপিরাইট/টেকডাউন ঝুঁকি, (২) ২৭ MB বান্ডিল → মোবাইলে স্লো, (৩) ৪৮টি প্রশ্ন অপশন ছাড়া ভাঙা অবস্থায় রেন্ডার হয়, (৪) কন্টেন্ট embed করার পদ্ধতিতে একটা ব্যাকটিক ঢুকলেই পুরো সাইট উড়ে যাবে।

| ক্যাটাগরি | সংখ্যা |
|---|---|
| 🔴 Critical (ডেলিভারির আগে ঠিক করুন) | 4 |
| 🟠 Medium (প্রথম সপ্তাহে ঠিক করুন) | 8 |
| 🟢 Low / polish | 8 |
| ✅ যা ঠিক আছে (সত্যিই ভালো) | 9 |

---

## 🔴 CRITICAL

### 1. কন্টেন্ট কপিরাইট ও টেকডাউন ঝুঁকি (সবচেয়ে বড় ব্যবসায়িক ঝুঁকি)

প্রশ্নব্যাংকটা paid বই ও কোচিং-সেন্টারের material থেকে **হুবহু** নেওয়া, এবং ডেটার ভিতরেই source-এর নাম, বইয়ের নাম, পৃষ্ঠা নম্বর, coaching brand লেখা আছে:

- `source_book` ফিল্ডে: `Varsoty_W03_Solution.pdf`, `W-07 Varsity (Udvash).pdf`, `Udvash Weekly 06`, `Varsity Master QB`, `DU Ka 15-Year Question Bank & ইসহাক স্যার`, `হাজারী-নাগ ও ঢাবি প্রশ্নব্যাংক`, `প্রফেসর ইসহাক (২য় পত্র, পৃ-২০৮)`, `উন্মেষ মেডিকেল`, `ড. মোহাম্মদ আবুল হাসান (১ম পত্র, পৃ-৪৪)` … মোট ~১৩০টি আলাদা বই/স্যারের নাম
- `du_repeat_tag`-এ: `DU '18-19 Hubohu | Repeated 3x | চ্যাপ্টারে 28টি DU/Varsity প্রশ্ন`
- `origin`-এ: `DU '11-12` … `DU '21-22 Hubohu`, `MAT '17 Direct` … `MAT '21 Direct`, `GST '20/21`, `RU '19-21`, `JU '18-20`, `CU '18-20`

এখন সাইটটা **public, Google-indexable, Facebook-group-shareable** — তাই এটা paid material-এর redistribution। ঝুঁকি: কোচিং সেন্টার/প্রকাশকের কাছ থেকে claim বা takedown, DMCA notice, এবং university-র academic-integrity নীতির প্রশ্ন।

**করণীয়:**
1. সব `source_book`, `du_repeat_tag`, `origin`-এর brand/বই/পৃষ্ঠা উদ্ধৃতি বাদ দিন (৩,৭৭৬ টি প্রশ্নেই আছে) — ব্যাখ্যা নিজের ভাষায় লিখুন
2. Source বই/কোচিং-এর কাছ থেকে written license নিন, অথবা public past-paper-এর উপর নিজের analysis-ই দেখান
3. `robots.txt` + সাইটে একটি DMCA/takedown contact page রাখুন
4. Bangladesh-এ কপিরাইট ও academic-integrity নিয়ে আইনি পরামর্শ নিন (শিক্ষামন্ত্রণ আইন ২০১৪-এ মূলধনসূত্র; বাংলাদেশ কপিরাইট আইন ২০১১-এ বই/সংগ্রহের জন্য নির্দিষ্ট শর্ত আছে)

### 2. বান্ডিল ২৭ MB — মোবাইলে ভারী, টাইমআউট ঝুঁকি

```
/assets/index-BVMUvLgv.js  →  27,272,165 bytes raw  /  3,797,949 bytes gzip
মোট প্রথম-লোড ট্রান্সফার  →  4.12 MB  (GTM 163 KB + Google Fonts 392 KB সহ)
পরিমাপিত FCP             →  3.0 সেকেন্ড (ভালো কানেকশনে, মোবাইল 390×844)
```

৮টি JSON ব্লব একসাথে bundle-এ ঢোকানো এবং `JSON.parse()` দিয়ে **স্টার্টআপেই** পুরোটা parse হয় (মোট ~৩,৭৭৬ প্রশ্ন + ৩৬৬ ফর্মুলা কার্ড + ২১৬ ফ্ল্যাশকার্ড)। 3G/4G-তে ৩.৮ MB = ৩০–৯০ সেকেন্ড; ২ GB RAM-এর ফোনে ২৭ MB parse RAM-এর কারণে tab crash করতে পারে।

**করণীয়:**
- ব্যাংকটা `src/data/week_01.json` … `week_09.json` হিসেবে আলাদা করুন, drill খুললে `await import()` / dynamic fetch দিয়ে lazy-load করুন
- Shell bundle < 500 KB রাখুন
- GTM বাদ দিন বা প্রথম paint-এর পরে load করুন; বাংলা ফন্ট self-host + subset করুন
- `React.lazy()` দিয়ে route-level code splitting

### 3. ৪৮টি প্রশ্ন row-এ অপশন নেই → ভাঙা কার্ড রেন্ডার হয়

`w9_phy_w01..w04`, `w9_che_w01..w04`, `w9_mat_w01..w04`, `w9_bio_w01..w04` — ১৬টি ইউনিক লিখিত-ধরনের প্রশ্ন, ৩টি ব্যাংকে (weekly/varsity/unset) কপি হওয়ায় **মোট ৪৮টি row**। এগুলোতে `opts: []`, `correct_index: null`, `ans: 0`।

লাইভ যাচাই: **Week 09 ড্রিলে (৭৬টি প্রশ্ন) Q16, Q17, Q18 … কার্ডগুলো A/B/C/D ছাড়াই রেন্ডার হয়** — শিক্ষার্থী দেখে কোনো অপশন পায় না, উত্তরও দিতে পারে না। কার্ডে "✍️ Written Essential" লেখা থাকলেও কোনো লিখিত-উত্তরের ইনপুট বা মডেল সলিউশন দেখানোর ব্যবস্থা নেই (শুধু "সব ব্যাখ্যা আনলক" বাটন)।

**করণীয়:** হয় ৪টি অপশন + উত্তর key দিন, অথবা `type: 'written'` চিহ্নিত করে written-ধরনের কার্ড (মডেল সলিউশনসহ) আলাদা করে রেন্ডার করুন। ID তালিকা: `fix-list.csv` (issue = `NO_OPTIONS`)

### 4. কন্টেন্ট embed করার পদ্ধতি ভাঙনো — একটা ব্যাকটিকেই পুরো সাইট উড়বে

ব্যাংকটা bundle-এ এভাবে বসানো: `uc = JSON.parse(\`[...]\`)` — টেমপ্লেট লিটারেল, তাই JS কন্টেন্ট-টা **evaluate** করে। প্রমাণ করা হয়েছে (সিমুলেশন):

```
একটা backtick ঢোকালে  → SyntaxError: Unexpected identifier 'ব্যাকটিক'  → পুরো bundle ক্র্যাশ
একটা ${x} ঢোকালে     → ReferenceError: x is not defined             → পুরো bundle ক্র্যাশ
```

আজকের কন্টেন্টে ০টি backtick ও ০টি `${` আছে (শুধু blob5-এ ৩টি `${`), কিন্তু **১,৬২২টি প্রশ্নেই আছে LaTeX `$…$`**। পরের সপ্তাহের solve sheet-এ একটা কোড স্যাম্পল বা hint-এ `` ` `` থাকলেই — সব ইউজারের জন্য সাদা স্ক্রিন। এটা আপনার actual "নতুন QB আপলোড" workflow-র সবচেয়ে বড় ঝুঁকি।

**করণীয়:** কখনোই কন্টেন্ট টেমপ্লেট লিটারেলে ঢোকাবেন না। আসল `.json` ফাইল ব্যবহার করুন (`import data from './data/week_01.json'`) অথবা JSON-escaped/base64 ব্যবহার করুন।

---

## 🟠 MEDIUM

### 5. সাইটের সংখ্যাগুলো ব্যাংকের সাথে মেলে না (এবং নিজেরাও মেলে না)

| কোথায় | দাবি | আসল |
|---|---|---|
| Weekly, সপ্তাহের কার্ড | W01 128 / W02 126 / W03 204 / W04 107 / W05 96 / W06 96 / W07 84 / W08 161 / W09 76 | weekly ব্যাংক: W01 **147** / W02 **144** / W03 **224** / W04 107 / W05 96 / W06 **120** / W07 84 / W08 161 / W09 76 |
| Weekly | "৭৫০টি উইকলি MCQ" | 1,083 (W01–W08), 1,159 (W01–W09) — আর সাইটের নিজের সপ্তাহ-সংখ্যাগুলো যোগ করলে 1,078 |
| Weekly | "৭ সপ্তাহ", "Week 01 – 08" | ৯ সপ্তাহের ডেটা আছে; উপরের নেভিগেও "W01-09" |
| Weekly | "১,৪৪৭টি প্রেডিক্টর MCQ" | ইউনিক id = 1,442 (৫টি কম) |
| Decks | "১,৩৪৭ প্রেডিক্টর", "৭৫০ MCQ", "৭টি উইকলি স্লট" | W01–W08 ইউনিক id = 1,308; মোট 1,442 |
| Decks | "৭৫ চ্যাপ্টার / ৭৫ অধ্যায়" | ব্যাংকে **১৪৩টি** আলাদা chapter নাম |
| Decks | "২২,৮০৭+ প্রশ্ন অ্যানালাইসিস" | ব্যাংকে 3,776 row (1,442 ইউনিক) — "অ্যানালাইসিস করা" হিসেবে বললে চলে, নইলে ৬ গুণ বেশি দেখাবে |

**করণীয়:** প্রতিটি সংখ্যা runtime-এ ডেটা থেকে calculate করুন; hardcoded মোট বাদ দিন।

### 6. ১,১২৮টি ID ৩–৪ বার করে এসেছে

একই প্রশ্ন, একই উত্তর — কিন্তু `bank_type` weekly/varsity/unset তিনটিতে একই `id` দিয়ে ঢোকানো। ফল: React duplicate key (state bleed), counter ওভার-কাউন্ট, একই উত্তর একসাথে ৩–৪ বার সেভ হয়।

**করণীয়:** row-ভিত্তিক unique id (`w1_phy_q01__weekly`) অথবা merge করার সময় `id` দিয়ে dedupe। তালিকা: `fix-list.csv` (issue = `DUPLICATE_ID`)

### 7. উত্তরের অবস্থানে বড় bias — প্রশ্নটা guess করা যায়

```
correct_index:  A = 1,560 (41.8%)   B = 1,208 (32.4%)   C = 655 (17.6%)   D = 305 (8.2%)
সুষম হওয়ার কথা ≈ 25% প্রতিটিতে
```

একজন শিক্ষার্থী শিখে গেল "সবসময় A" → ৬০ প্রশ্নের পেপারে chance-এর চেয়ে ~১৭ নম্বর বেশি। এটাই এই ধরনের অ্যাপের সবচেয়ে বড় দুর্বলতা।

**করণীয়:** প্রতি session-এ অপশন shuffle করুন (mapping সংরক্ষণ করে), অথবা ব্যাংক rebalance করুন।

### 8. `track` ফিল্ডে casing ভিন্ন

`'varsity'` 1,995 | `'Varsity'` 72 | `undefined` 857 | `'medical'` 852। যেকোনো `=== 'varsity'` filter ৭২টি প্রশ্ন silently বাদ দেয়, আর ৮৫৭টি track-based ভিউতে দেখাবে না।

**করণীয়:** load-এর সময় একটি enum-এ normalize করুন।

### 9. লগইন মডালে "ক্লাউডে সেভ" প্রতিশ্রুতি, কিন্তু ক্লাউড নেই

মডালে লেখা: *"রিয়েলটাইম পরীক্ষার মার্কস, নেগেটিভ মার্কিং ট্র্যাকার এবং অ্যানালিটিক্স নিরাপদে ক্লাউডে সংরক্ষণ করুন"*

বাস্তবে:
- Firestore প্রজেক্টে **enabled-ই নেই** → API বলছে *"Cloud Firestore API has not been used in project admission-crack-2026"*
- bundle-এ `getFirestore` / `setDoc` / `doc()` — ০টি কল; Storage ও RTDB bucket নেই
- সব progress শুধু `localStorage`-এ (`admission_weekly_user_answers`, `admission_user`)

**করণীয়:** হয় Firestore enable করে rules লিখে sync বাস্তব করুন, নয়তো মডালের লেখা বদলে দিন ("ডিভাইসেই সেভ থাকে; নতুন ডিভাইসে লগইন করলে ট্র্যাকার শুরু")।

### 10. COOP এররে লগইন বাটন আটকে যেতে পারে

"Continue with Google" চাপলে console-এ: `Cross-Origin-Opener-Policy policy would block the window.closed call.` Firebase পপ-আপ বন্ধ হয়েছে কিনা `window.closed` দিয়ে check করে — block হলে UI **"Google এ লগইন হচ্ছে..."**-তে আটকে থাকতে পারে।

**করণীয়:** Vercel-এ header যোগ করুন → `Cross-Origin-Opener-Policy: same-origin-allow-popups`

### 11. Share/SEO meta নেই — Facebook-এ লিংকের preview ফাঁকা

`index.html`-এ **নেই**: `meta description`, `og:title / og:description / og:image / og:url`, `twitter:card`, canonical link। ফলে Facebook/WhatsApp-এ শেয়ার করলে ছবি ও বিবরণ ছাড়া শুধু title দেখাবে।

এছাড়া `/robots.txt` ও `/sitemap.xml` ফাইল নেই — দুটোই **SPA fallback HTML, HTTP 200** ফেরত দেয়; যেকোনো অচেনা path-এও একই (soft-404 সার্জ)।

**করণীয়:** `public/robots.txt` + `public/sitemap.xml` বানান, meta/og tag দিন, Vercel-এ unknown path-এর জন্য 404 configure করুন।

---

## 🟢 LOW / POLISH

| # | সমস্যা | ঠিক করার উপায় |
|---|---|---|
| 12 | `dangerouslySetInnerHTML` ব্যবহার হয়েছে, কোনো sanitiser নেই (DOMPurify/rehype-raw নেই) | আজকের static ব্যাংকে exploitable নয়, কিন্তু ভবিষ্যতে import/upload feature যোগ করলেই stored XSS — DOMPurity বসান |
| 13 | `user-scalable=no` → pinch-zoom বন্ধ (WCAG 1.4.4) | viewport থেকে বাদ দিন |
| 14 | index.html-এ `accounts.google.com/gsi/client` লোড হয় কিন্তু bundle-এ `google.accounts` কোনো কল নেই (Firebase `signInWithPopup` ব্যবহার করে) | dead script সরান — অপ্রয়োজনীয় third-party |
| 15 | Service worker পুরো ২৭ MB bundle প্রতিটি ডিভাইসের Cache Storage-এ লিখে; আর অচেনা path-এর জন্য SPA HTML cache করে | বড় asset-এর cache skip/guard; 404 handle করুন |
| 16 | ৩৮৯টি ব্যাখ্যা ৬০ অক্ষরের কম (সবচেয়ে ছোট ২৩) — "সলিউশন শীট" প্রোডাক্টের জন্য যথেষ্ট নয় | ব্যাখ্যা সম্পূর্ণ করুন |
| 17 | নতুন ইউজারকে উত্তর দেওয়ার আগেই ১০০% accuracy দেখায় (`accuracy > 0 ? accuracy : 100`) | default 0 রাখুন |
| 18 | Firebase API key (`AIzaSyBXWuUwwDeAo1zKBjWywEz8524FI6yONjo`) ও project id বান্ডেলে — Firebase web-এ এটা স্বাভাবিক, তবে Console-এ Email/Password signup নিশ্চিত disabled আছে কিনা দেখুন, লেখার ফাইল থাকলে key rotate করুন | console check |
| 19 | Firebase Analytics + GA4 দুটোই চলছে, কোনো consent notice নেই | privacy/consent page যোগ করুন (শিক্ষার্থীদের অনেকের বয়স কম) |
| 20 | `probablity` ফিল্ড homogeneous নয় — `"98%"`, `"98% DU 'Ka' Pattern Repeat"`, `"99% DU & Varsity Hotspot"` মিশ্র | numeric field আলাদা করুন (probability_num + label) |

---

## ✅ যা ঠিক আছে (এগুলো নিয়ে দুশ্চিন্তা থাকার দরকার নেই)

- **কোনো JS/page error নেই** — ১৩টি route (`decks`, `weekly`, `paper_final`, `subject_final`, `full_mock`, `exam`, `predictor`, `slides`, `flashcards`, `analytics`, `vault`, `recall`, `blueprint`) সব সরাসরি লোডে খুলে যায়, শূন্য error
- **KaTeX পরিষ্কার** — ১৬৭টি ফর্মুলা render, ০টি `katex-error`; মোজা��া (U+FFFD) ০টি; broken image ০টি
- **উত্তর key self-consistent** — ১,৬১৫টি numeric প্রশ্নের উত্তর তার নিজের ব্যাখ্যার সাথে মেলানো হয়েছে; flagged ৩.৪% ম্যানুয়াল দেখে শুধু wording-এর পার্থক্য, ভুল key নয়
- **Google login কাজ করে** — popup ঠিকভাবে খোলে, `admissionwebapp.vercel.app` Firebase-এ authorized domain হিসেবে আছে
- **কোনো secret leak নেই** — `client_secret`, service account key, `GOCSPX-` token কোনোটিই নেই
- **`.env` leak নেই** — `/api/*`, `/.env`, `/robots.txt` সব SPA fallback HTML ফেরত দেয়, আসল ফাইল নয়
- **HTTPS + HSTS চালু** (`strict-transport-security: max-age=63072000`), CSP নেই (vercel.json-এ যোগ করা উচিত)
- **PWA ঠিকভাবে কাজ করছে** — service worker register হয়, `manifest.json`, `logo192/512.png`, `favicon.ico` সব বিদ্যমান
- **উত্তর localStorage-এ সেভ হয়** — `{"week_09":{"w9_phy_q01":"A"}}` ফরম্যাট ঠিক আছে

---

## করণীয়ের অগ্রাধিকার (এই ক্রমে করুন)

| ক্রম | কাজ | সময় |
|---|---|---|
| 1 | কন্টেন্টের source ব্র্যান্ড/বই/পৃষ্ঠা উদ্ধৃতি সরান + DMCA contact + কপিরাইট পরামর্শ | আগে |
| 2 | ব্যাংক → আলাদা JSON ফাইল, lazy-load (২৭ MB → ~৫ MB) | আগে |
| 3 | `JSON.parse(\`...\`)` → আসল `.json` import (ব্যাকটিক ঝুঁকি সরান) | আগে |
| 4 | ৪৮টি অপশনবিহীন প্রশ্ন ঠিক করুন | আগে |
| 5 | সব সংখ্যা runtime-এ calculate করুন; সপ্তাহ ৭ → ৯ ঠিক করুন | ১ সপ্তাহ |
| 6 | ID unique করুন, `track` normalize করুন | ১ সপ্তাহ |
| 7 | অপশন shuffle করুন (A-bias ঠিক করতে) | ২ সপ্তাহ |
| 8 | og/meta/robots/sitemap + COOP header | ১ সপ্তাহ |
| 9 | "ক্লাউডে সেভ" প্রতিশ্রুতি — Firestore না লেখার ভাষা বদলান | ১ সপ্তাহ |
| 10 | DOMPurify, viewport zoom, dead GSI script সরান | ২ সপ্তাহ |

---

*এই রিভিউটা deployed build ও live browser-এর উপর চালানো; সোর্স কোড (React + Vite) workspace-এ ছিল না, তাই কোড-লেভেল ফিক্স লিখা হয়নি — নির্দিষ্ট লাইন/ফাইল বলতে পারছি না, কিন্তু সব সমস্যা চিহ্নিত ডেটা ও ফাইল-পরিস্থিতি দিয়ে বর্ণনা করা হয়েছে।*
