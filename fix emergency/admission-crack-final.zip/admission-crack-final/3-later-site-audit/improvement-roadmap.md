# Improvement Roadmap + SEO/ranking plan
**সাইট:** https://admissionwebapp.vercel.app
**তারিখ:** 17 নভেম্বর 2026 · রিভিউ রাউন্ড ২

---

## ভূমিকা: র‍্যাঙ্ক করা কি possible?

**হ্যাঁ — কিন্তু এখনকার অবস্থায় না।** মূল কারণ দুটো, দুটোই যাচাই করা:

1. **Google তোমার সাইট মাত্র ১টা URL হিসেবে দেখে** — "/"। বাকি ২৪টা route (`/weekly`, `/paper_final`, `/full_mock`, `/predictor`, `/vault`…) `#hash` দিয়ে address bar-এ আসে, আর Google URL-এর fragment অংশ ইগনোর করে। ফলে তোমার ৩,৭৭৬ প্রশ্ন, ১৪৩টি chapter, ২২,৮০৭+ প্রশ্নের বিশ্লেষণ — সবগুলো একটা URL-এর নিচে চাপা। কোনোটাই আলাদা page হিসেবে index হবে না, মানে কোনো query-তে rank করার আলাদা entry থাকবে না।
2. **Googlebot-কে যা যায়**: শুধু `<div id="root"></div>` — পুরো কনটেন্ট JS render-এর পরে আসে, আর সেই JS হলো **২৭ MB** (brotli-তেও ৩.৮ MB)। Google-এর render budget-এ এটা ঝুঁকিপূর্ণ; render ব্যর্থ হলে পেজ thin content হয়ে যায় (কনটেন্ট দেখাবে না)।

### যাচাই করা SEO অবস্থা (as-is)

| বিষয় | বর্তমান অবস্থা | লক্ষ্য |
|---|---|---|
| Indexable URL | ১টি (`/`) | ২০–৪০টি (route + chapter + subject) |
| Title | **প্রতিটি route-এ একই**: `Admission Crack 2026 \| DU 'Ka' & Medical Chorcha Deck` | প্রতিটি page-এ unique title |
| meta description | ❌ নেই | প্রতিটি page-এ ১৫০–১৬০ অক্ষর |
| og:title / og:description / og:image | ❌ নেই | থাকতে হবে (FB/WhatsApp share preview) |
| twitter:card | ❌ নেই | থাকতে হবে |
| canonical | ❌ নেই | self-canonical |
| JSON-LD (structured data) | ❌ নেই | Quiz + FAQ + SoftwareApplication + BreadcrumbList + Organization |
| robots.txt | ❌ নেই (SPA fallback HTML, 200) | real file |
| sitemap.xml | ❌ নেই (SPA fallback HTML, 200) | real file |
| Custom domain | ❌ `*.vercel.app` (shared domain, নিজস্ব authority নেই) | নিজের `.com` / `.com.bd` |
| JS bundle | ২৭ MB raw / ৩.৮ MB brotli | shell < ৫০০ KB, bank আলাদা JSON |
| LCP/FCP | FCP মাপা ৩.০ সেকেন্ড | < ২.৫ s mobile |

### বাজেট (benchmark) — তুমি এখন কার সাথে লড়ছো

`duetadmission.com` — একই niche (DUET/DU admission), **server-rendered**, real URL (`/question-bank`, `/previous-years/years`), নিজের sitemap, AdSense দিয়ে monetize করছে, ৪১,৯৭৮ প্রশ্ন দেখাচ্ছে। তার কাছ থেকে Google-এ organic traffic নেওয়ার জন্য তোমাকে অন্তত **equal বা better crawlable surface** লাগবে।

### Rank করার জন্য ৫টি আবশ্যক শর্ত (এই ক্রমে)

**১. Custom domain** — `admissioncrack.com` / `*.com.bd` ইত্য। `vercel.app` একটা shared subdomain: কোনো brand authority নেই, backlink দিতে অন্যরা দ্বিধা করবে, ছাত্ররা "vercel.app" দেখে trust কম পায়। সবচেয়ে সস্তা কিন্তু সবচেয়ে বেশি ROI-র পদক্ষেপ।

**২. Real URL (hash routing → path routing)** — দুইটা অপশন:
- (ক) React Router `BrowserRouter` + Vercel-এ rewrite (`vercel.json` → `{"rewrites":[{"source":"/(.*)","destination":"/index.html"}]}`) — সহজ, কিন্তু সব page render-এর আগে খালি।
- (খ) **Vite SSG / prerender** — route অনুযায়ী static HTML ফাইল generate করুন (`/weekly/index.html` ইত্যাদি)। এতে Google প্রতিটি page-এর কনটেন্ট সরাসরি পাবে, render-এর উপর নির্ভরশীল থাকবে না। **এটাই এই niche-এ সবচেয়ে কার্যকর একটা পদক্ষেপ** — কারণ এই ধরনের সাইটে লাখ লাখ কনটেন্ট page থাকে এবং search bot-এর জন্য crawl-কে সস্তা করা যায়।

**৩. Per-route SEO + structured data**
- প্রতিটি route-এ unique `<title>` + `<meta name="description">` + canonical
- JSON-LD: `Quiz`/`Question` (প্রশ্নের জন্য), `FAQPage`, `SoftwareApplication`, `BreadcrumbList`, `Organization`
- `og:image` — 1200×630 PNG, `/og.png`, absolute URL (FB preview ছাড়া share করলে preview ফাঁকা থাকে)

**৪. robots.txt + sitemap.xml** — real file, `public/`-এ রাখুন। sitemap-এ শুধু canonical, indexable URL দিন।

**৫. Performance (CWV)** — ২৭ MB → <১ MB shell। এটা শুধু ranking না, **crawl budget ও conversion** দুটোই। ৩ সেকেন্ডের বেশি লোডে ৫০%+ ব্যবহারকারী ফিরে যায়।

### কোন query-তে rank করা বাস্তবসম্মত

| Query ধরন | টার্গেট | সম্ভাবনা |
|---|---|---|
| "ঢাবি অ্যাডমিশন প্রশ্নব্যাংক", "DU 'Ka' প্রশ্ন" | head, প্রতিযোগী তীব্র | ❌ ৬–১২ মাসে কঠিন |
| "ঢাবি ১ম পত্র MCQ ও সলিউশন", "MEDICAL MAT প্রশ্ন" | mid | ⚠️ সম্ভব, যদি chapter-level page থাকে |
| "[বিষয়] repeated question DU", "DU '21-22 physics প্রশ্ন" | long-tail | ✅ সবচেয়ে বাস্তবসম্মত — **প্রতিটি chapter × প্রতিটি বছরের আলাদা page** বানালে এটা হাজার হাজার indexable page |
| "ঢাবি অ্যাডমিশন কাট-অফ প্রেডিকশন ২০২৬" | branded | ✅ তোমার আপনি, দ্রুত rank করবে |

### এই niche-এ আসল traffic কোথায় আসে

বাংলা exam-seeker-দের বড় অংশ Google-এ না, **Telegram / YouTube / Facebook group**-এ search করে। তাই Google-এর চেয়ে দ্রুত growth হবে:
- Telegram bot/channel: প্রতিদিন ১৫টি প্রশ্ন + "আজকের trend" পোস্ট
- YouTube: সাপ্তাহিক "DU Ka Chapter-এর সবচেয়ে বেশি repeat প্রশ্ন" ভিডিও (ভিডিও থেকা মানুষ সাইটে আসবে)
- Facebook group-এ share card (share-এর জন্য og:image দরকার)

---

## উন্নতির roadmap

### A. প্রোডাক্ট ফিচার (যেগুলো শিক্ষার্থী মনে রাখবে)

1. **Weakness Radar** — কোন chapter/subject-এ কত% দুর্বল, "এই ৫টি chapter আগে পড়ো"। এখন `admission_weekly_user_answers`-এ ডেটা আছে, UI নেই।
2. **A-bias ঠিক করা + প্রতি session-এ অপশন shuffle** — ৪১.৮% উত্তর A-তে; shuffle করলে এই সুযোগ বন্ধ, আর শিক্ষার্থীর প্রস্তুতি বাস্তবসম্মত হয়।
3. **প্রেডিকশন → যাচাই (Prediction validation)** — আগের বছরের আসল প্রশ্নের সাথে তোমার predictor-এর হিট-রেট দেখানো ("২০২৪ সালে আমাদের ৯৮% hit rate")। এটাই সবচেয়ে বড় trust-builder; কিন্তু সত্য হতে হবে।
4. **"আমার প্রস্তুতি" প্ল্যানার** — কত দিন বাকি, কত MCQ বাকি, daily target।
5. **Real exam simulation** — টাইমার, negative marking (০.২৫), প্রশ্ন পাল্টানো, ৩০ সেকেন্ড পার প্রশ্ন সতর্কতা — সব একসাথে চালু হবে।
6. **WhatsApp share + referral** — "আমার ৮৩% প্রস্তুতি, তুমি কত? এই লিংকে ক্লিক করো"। referral-এর জন্য প্রতিটি ইউজারকে unique code।
7. **Print/PDF solution sheet** — offline-এ থাকা সলিউশন PDF (প্রিন্ট করে ফোল্ড করে রাখার কাজ দেয়)।
8. **Spaced repetition** — ভুল করা প্রশ্নগুলো ১-৩-৭-১৪ দিনে ফিরে আসুক (SM-2)।
9. **Install prompt (PWA)** — iOS-এ "Add to Home Screen" prompt দেখানো (Android-এ automatically হয় না)।
10. **প্রশ্ন-স্তরে নোট (sticky note)** — নিজের মন্তব্য, পরে দেখার জন্য।
11. **Bank-এর ভিতরে সার্চ/ফিল্টার** — "বায়োলজি কোষ ও রক্ত, DU repeat" লিখে সাথে সাথে প্রশ্ন।
12. **Error-report button** — ভুল উত্তর/টাইপ-ভুল প্রশ্ন রিপোর্ট করার বাটন → তুমি সরাসরি করেকশন পাবে।
13. **Leaderboard (opt-in, ছদ্মনাম)** — সপ্তাহিক র‍্যাঙ্কিং।
14. **Solution-sheet quality pass** — ৩৮৯টি ব্যাখ্যা ৬০ অক্ষরের কম, মিনিমাম ২২৩ অক্ষর।
15. **প্রশ্নের "প্রায়-নিশ্চিত/সম্ভাব্য/সন্দেহযোগ্য" তিন-স্তরের ট্যাগ** — probability ফিল্ডকে numeric করে (এখন `"98% DU 'Ka' Pattern Repeat"` মিশ্র string)।

### B. ইঞ্জিনিয়ারিং ও পারফরম্যান্স

1. **ব্যাংক → আলাদা JSON ফাইল, lazy import** — `import()` / dynamic fetch; drill খুললে তবেই ডাউনলোড।
2. **React.lazy + route-level code splitting** — Deck/Weekly/Mock আলাদা chunk।
3. **CI-তে data-lint স্ক্রিপ্ট** (সবচেয়ে বেশি leverage) — duplicate id, zero-option প্রশ্ন, per-week count mismatch, A-bias, `track` casing — **আমি যে ৫টা বাগ পেয়েছি, এই একটা স্ক্রিপ্ট pre-commit-এ ধরে ফেলত**।
4. **Service worker strategy ঠিক করা** — HTML: network-first; JSON bank: stale-while-revalidate; ২৭ MB-এর মতো asset cache না করা; unknown URL-এর জন্য offline fallback না দেখানো।
5. **Font subsetting + self-host** — Solaiman Lipi/Hind Siliguri ৩৯২ KB Google Fonts থেকে আসছে; বাংলা subset + `font-display: swap`।
6. **GTM defer** — প্রথম paint-এর পরে load, অথবা Firebase Analytics-ই রাখুন (দুটোই চলছে — duplicate tracking)।
7. **DOMPurify + CSP header** — `dangerouslySetInnerHTML`-এ sanitize; `vercel.json`-এ CSP + `Cross-Origin-Opener-Policy: same-origin-allow-popups`।
8. **IndexedDB** — localStorage-এর ৫ MB সীমা; উত্তরের ইতিহাস ও flashcard state-এর জন্য।
9. **Error tracking** — Sentry বা নিজের beacon; আজ কোনো runtime error হলেও আপনি জানবেন না।
10. **Edge/ISR caching** — JSON bank Vercel Edge Cache-এ, invalidation content-hash দিয়ে।
11. **Prefetch next week's drill** — idle সময়ে পরের সপ্তাহের JSON আগে থেকে নামানো।
12. **A11y** — `user-scalable=no` সরান (WCAG 1.4.4), focus ring, `aria-label` on icon buttons।

### C. বিজনেস, লিগ্যাল ও মনিটাইজেশন

1. **কনটেন্ট লাইসেন্স** — বই/কোচিং-এর কাছ থেকে written permission (এটা আগে; নাহলে scale করা বিপদ)।
2. **AdSense** — competitor এটা করছে; free tier-এ ads, premium tier-এ ads ছাড়া।
3. **Paid tier** — premium mock, PDF solution pack, ১:১ "কোন chapter আগে" plan।
4. **Referral program** — দুই পাশেই reward।
5. **Privacy + consent page** — শিক্ষার্থীদের অনেকের বয়স ১৬–১৮; কোকিয় consent ও data-retention লিখুন।
6. **Firebase Console housekeeping** — Email/Password signup নিশ্চিত disabled, App Check চালু, key rotation policy।
7. **Product analytics** — শুধু pageview না, `drill_started`, `question_answered`, `explanation_opened`, `mock_completed` — এগুলো দিয়ে কোন ফিচার কাজ করে সেটা বোঝা যাবে।

---

## ৪-সপ্তাহের অ্যাকশন প্ল্যান

| সপ্তাহ | কাজ | ফলাফল |
|---|---|---|
| ১ | ৪টি critical fix (কনটেন্ট-ক্লিনআপ, JSON split, backtick fix, ৪৮টি প্রশ্ন ঠিক) + CI data-lint স্ক্রিপ্ট | সাইট স্থিতিশীল, নতুন কনটেন্ট যোগ করা নিরাপদ |
| ২ | Custom domain + real routing/SSG + per-route title/meta/canonical + robots/sitemap + JSON-LD | **indexable হওয়ার শর্ত তৈরি** |
| ৩ | Bundle < ১ MB (lazy route, font subset, GTM defer, SW fix) + Weakness Radar + option shuffle | LCP ঠিক, A-bias বন্ধ, retention বাড়ে |
| ৪ | Telegram/YouTube launch + referral + og:image + product analytics | প্রথম traction, ranking-এর জন্য backlink ও signal |

---

## সৎ উত্তর

- **Google-এ head term ("ঢাবি প্রশ্নব্যাংক")** — ১ বছরের মধ্যে প্রথম পাতায় আসা কঠিন, কারণ প্রতিযোগীরা SSR + বছরের বছরে কনটেন্ট + backlink আছে।
- **Long-tail (বিষয় × অধ্যায় × বছর)** — ৩–৬ মাসে বাস্তবসম্মত, **যদি প্রতিটি chapter/year-এর আলাদা indexable page থাকে**। এটাই আসল কাজ।
- **Telegram/YouTube** — এই niche-এ ১–৩ মাসেই বড় traction আসবে, Google-এর চেয়ে অনেক দ্রুত।
- **আগে যা করতেই হবে:** কনটেন্ট লাইসেন্স। কপিরাইট ঝুঁকি থাকা অবস্থায় traffic আসলেই ঝুঁকি বাড়বে, কমবে না — কারণ claim আসলে জরিবানির ঝুঁকি থাকে।
