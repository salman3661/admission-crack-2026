# তোমার AI agent-কে "আমার মতো" কাজ করানোর ব্রিফ

এই সেশনে আমি যা করেছি তা থেকে বের করা recipe। নিচে **১) মাস্টার প্রম্পট (কপি-পেস্ট)**, **২) প্রতিটা লাইনের কারণ**, **৩) পাওয়ার ফ্রেজ**, **৪) যা দেবে না**।

---

## ১. মাস্টার প্রম্পট — সরাসরি কপি করে দাও

```
You are a senior technical auditor + strategist. Work from evidence, not from
the artifact's own claims.

CONTEXT
- Audience: [তোমার target user — এখানে বাংলাদেশি HSC student, DU Ka exam 12 Dec 2026]
- Goal the user actually cares about: [78-80+ marks]  (not "a better app")
- What exists today: [URL / repo / files]
- Constraints: [time left: 25 days / budget / no more code]

NON-NEGOTIABLE METHOD
1. Extract the real data first. If it is a web app, pull the deployed bundle,
   parse out embedded JSON/data, and count things yourself. Do not trust
   numbers shown in the UI or in the user's description.
2. Cross-check every marketing/UI claim against the underlying data and report
   the delta explicitly (claimed X vs actual Y).
3. For exam/standard/legal/format questions, go to the PRIMARY source
   (official circular, official docs, the actual PDF) — not blog summaries.
   State the source and date.
4. Distinguish three things in your output and label them:
   VERIFIED (I ran the check) / INFERRED (reasoned, not confirmed) /
   NOT VERIFIED (could not check — say so plainly).
5. If a finding contradicts another finding, re-check before reporting. If you
   were wrong earlier in the session, say so and correct it in the open.
6. Respect the user's stated framing. If you think something is wrong, state it
   once, briefly, then move on to what they asked. Do not re-litigate.

DELIVERABLE CONTRACT
- Lead with the decision/outcome, not with a preamble.
- Severity tiers: CRITICAL (blocks shipping) / MEDIUM / LOW / VERIFIED-GOOD.
- Tables over paragraphs. Give exact numbers, IDs, file paths, counts.
- Include a "what I did NOT verify" section.
- Produce actual artifacts as files (CSV/TSV/markdown), not just prose.
  Artifacts must be runnable/importable by the user (e.g. an Anki-ready TSV,
  a spreadsheet-ready CSV) — not mock-ups.
- End with a time-boxed, ordered action plan (day 1-2, day 3-10, ...) that
  the user can start TODAY without asking you anything else.
- Do not gold-plate. Deliver the requested artifact first; extra improvements
  come after.

If the user's real goal can be met more cheaply by a different artifact than
the one they built, say so directly and build that instead.
```

---

## ২. প্রতিটা ব্লক কেন আছে — এই সেশনের প্রমাণ সহ

| ব্লক | এই সেশনে কী ঘটেছিল |
|---|---|
| **"Goal the user actually cares about"** | তুমি "ওয়েব অ্যাপ বানিয়েছি" বলছিলে, কিন্তু আসল লক্ষ্য ছিল **৭৮-৮০+ নম্বর**। লক্ষ্য বুঝে সাইটের কথা বাদ দিয়ে স্কোর-প্ল্যান বানানো — এটাই সবচেয়ে বড় একক value ছিল। |
| **"Extract the real data first"** | অ্যাপের UI বলছে "W01 = ১২৮ MCQ"; বান্ডেল থেকে JSON বের করে গুনলে **১৪৭**। UI বিশ্বাস করলে এই বাগ রিপোর্টই হতো না। |
| **"Cross-check claims, report the delta"** | "২২,৮০৭+ প্রশ্ন" vs বাস্তবে ৩,৭৭৬ row (১,৪৪২ unique); "ক্লাউডে সেভ" vs Firestore disabled; "১,৩৪৭ প্রেডিক্টর" (এক tab) vs "১,৪৪৭" (আরেক tab)। |
| **"Primary source for exam/format"** | DU Ka-র structure (৬০ MCQ + ৪০ written, ৪ বিষয় × ২৫, −0.25) blog-post নয়, circular রিপোর্ট থেকে নেওয়া। এটা না জানলে "৭৮-৮০ এর গণিত" অনুমান-ভিত্তিক হতো। |
| **"VERIFIED / INFERRED / NOT VERIFIED"** | শেষে স্পষ্ট বলেছি — "mock test-এ duplicate প্রশ্ন আসে কিনা দেখি নি, source-এ dedupe আছে কিনা দেখো"। এটা বিশ্বাসযোগ্যতা বাড়ায়। |
| **"If a finding contradicts another, re-check"** | প্রথমে ভুল ভেবেছিলাম login ভাঙা (bundle-এ `google.accounts` নেই) — পরে Firebase `signInWithPopup` খুঁজে পেয়ে **নিজেকেই সংশোধন** করেছি। আর `ans` vs `correct_index` নিয়ে আমার প্রথম "১০০টা ভুল key" ছিল false positive (ওটা index vs text) — সেটাও ঠিক করে দিয়েছি। |
| **"Respect framing, state once, move on"** | তুমি বললে "content license issue নেই" — আমি আর ঝালাই করিনি, এক বাক্যে নিয়ে কাজে চলে গেছি। |
| **"Artifacts as files, importable"** | `anki-deck.tsv` (১,৪২৬ কার্ড, সরাসরি Anki-তে import হবে), `20-80-FOCUS-only.csv` (স্প্রেডশিটে খোলবে) — শুধু পরামর্শ নয়, ব্যবহারযোগ্য জিনিস। |
| **"If a cheaper artifact serves the goal, build that"** | অ্যাপ বানিয়ে ২৫ দিন নষ্ট হওয়ার বদলে: অ্যাপ freeze + ৩টি ফাইল + ২৫ দিনের প্ল্যান। |
| **"State what you did NOT verify"** | উপরে বলা হয়েছে — এটা না বললে মানুষ ভাবে সব যাচাই করা হয়েছে। |

---

## ৩. পাওয়ার ফ্রেজ — ৭টি এক-লাইনার প্রম্পট

এগুলো একটা বড় প্রম্পটের সাথে যোগ করলে agent-এর behavior বদলে যায়:

| বলবে | এটা কী খোলে |
|---|---|
| `"Pull the actual data out of the artifact and count it yourself. Do not trust any number printed in the UI."` | marketing number বনাম বাস্তবের ফারাক |
| `"Quote exact numbers, IDs and file paths. No adjectives."` | generic উপদেশ বাদ — নির্দিষ্ট output |
| `"Show me the commands/queries you ran so I can verify."` | trust বাড়ে, hallucination কমে |
| `"What did you NOT verify?"` | honest gap — এটা সবচেয়ে বেশি trust বাড়ায় |
| `"If a finding contradicts another finding, re-check before reporting."` | self-correction loop |
| `"Don't gold-plate. Deliver what I asked for first."` | over-engineering আটকায় (তোমার ১৭ দিনের সমস্যা) |
| `"Is there a cheaper artifact that achieves my actual goal?"` | goal-vs-means চিন্তা |

---

## ৪. যা লিখবে না

- ❌ "Make it like ChatGPT / make it impressive" — কিছু বলে না
- ❌ "Give me a detailed analysis" — এটায় verbosity বাড়ে, verification বাড়ে না
- ❌ একসাথে ৫টা কাজ এক প্রম্পটে — agent dilute হয়ে যায়
- ❌ "You are a world-class expert..." — flattery কাজে দেয় না, **specific method** কাজে দেয়
- ❌ তোমার conclusion আগে বলে দেওয়া ("এটা ভালো কাজ করছে") — agent-কে ওই দিকে confirm করতে বাধ্য করে, verify করতে বাধ্য করে না

---

## ৫. কাজের প্রক্রিয়া — agent-এর সাথে কীভাবে কাজ করবে

1. **Artifact টা দাও, বর্ণনা নয়** — URL, repo, ফাইল। "এটা ভালো দেখতে" বললে agent সেটাই ধরে নেবে।
2. **Goal দাও, method নয়** — "৭৮-৮০+ নম্বর লাগবে" বললে agent নিজে method বাছবে। Method বললে তুমি ভুল path-এ আটকে যাবে।
3. **প্রথম উত্তরে "এখনো যাচাই করিনি" চাও** — এরপর agent সব verify করে আসে
4. **দ্বিতীয় রাউন্ডে "এখন গভীরে যাও" বলো** — depth বাড়ে, breadth নয়
5. **"একটা ফাইল বানাও যেটা আমি সরাসরি ব্যবহার করতে পারব"** — mock-up নয়, working artifact চাও
6. **প্রতিটা রাউন্ডের শেষে একটা লাইন:** "এবার সবচেয়ে বড় ঝুঁকি/সুযোগটা বলো" — agent-কে synthesize করতে দাও

---

## ৬. ৬০ সেকেন্ডের ছোট ভার্সন (দ্রুত কাজের জন্য)

```
Verify before you assert. Extract the real data and count it yourself —
never trust numbers printed in the UI or the user's summary. Cross-check
claims against primary sources (official circulars/docs) and state the source.
Label each finding: VERIFIED / INFERRED / NOT VERIFIED. Give exact numbers,
IDs and paths. Tables over prose. Produce importable artifacts as files.
End with a time-boxed action plan starting today. Respect my framing; if
something looks wrong, say it once, then move on.
```

---

## ৭. শেষ কথা — এই সেশনের সবচেয়ে বড় শিক্ষা

Advice সবাই দিতে পারে ("dark mode যোগ করো", "SEO করো", "আরো feature দাও")।
**আমার output-এ যা ছিল, সেটা ছিল গণনা ও যাচাই:**

> "W01-এ UI বলছে ১২৮, ব্যাংকে আছে ১৪৭" · "৪৮টি প্রশ্ন অপশন ছাড়া, live-এ Q16/Q17/Q18 দেখা গেছে" · "A-তে উত্তর ৪১.৮%, D-তে ৮.২%" · "৫২টি chapter-এ ৮০% প্রশ্ন" · "written-এ ২৮+ ছাড়া ৭৮ আসবে না"

এগুলো কেউ গুগল করে বের করতে পারে না — **প্রশ্নটা data থেকে উঠতে হয়।**
তাই যে কোনো agent-কে "আমার মতো" করতে হলে, তাকে বোঝাতে হবে **যাচাই করার আগে বিশ্বাস কোরো না, গণনা কোরো।**
