# ২৫ দিনের রোডম্যাপ — Exam Hall পর্যন্ত
**আজ ১৭ নভে ২০২৬ · DU Ka: ১২ ডিসে · MAT: ১৮ ডিসে (মাঝে ৬ দিন)**

---

## মূল কৌশল: এক প্রস্তুতি, দুই পরীক্ষা

```
DU Ka (১০০ নম্বর)          MAT (১০০ নম্বর)
Physics    25  ┐            Physics  20
Chemistry  25  ├────────►  Chemistry 25   ◄── একই syllabus!
Biology    25  │  ~৭৫ নম্বর  Biology  30
Math       25  ┘  একই জিনিস English  15
                        GK      10
```

**DU Ka-র Physics+Chem+Bio+Math আর MAT-র Physics+Chem+Bio — মোট ~৭৫ নম্বর একই chapter থেকে।** তাই ২৫ দিনের preparation দুটো পরীক্ষায়ই লাগবে। **DU Ka-কে ৭৮-৮০ করলে MAT-এ ৭৫+ আসবেই** (MAT-এ written নেই, তাই MCQ accuracy-ই সব)।

---

## 📅 ক্যালেন্ডার (১৭ নভে → ১৮ ডিসে)

### PHASE 1 · CONCEPT LOCK (১৭–২১ নভে, D-25 → D-21) — ৫ দিন
```
প্রতিদিন ৩.৫ ঘণ্টা:
  · ২ টি focus chapter পড়ো (20-80-FOCUS-only.csv দেখে)
  · ওই chapter-এর SET-A প্রশ্নগুলো বের করো (master-set-chapter-map.csv)
  · ভুল হলে error log-এ লেখো
শেষে: SET-A (DU Ka) ৬০ প্রশ্ন একবার timed
বিষায় ভাগ: Math ২ দিন · Chem ১.৫ · Physics ১ · Biology ১.৫
```
**🎯 Coaching Paper Final-এর আগে এটা শেষ করতেই হবে।** Paper Final হলো তোমার baseline — ওটার আগে concept lock করা যাবে না, কারণ ওটা তোমাকে বলে দেবে কোথায় ফাঁক আছে।

---

### PHASE 2 · DRILL + WRITTEN (২২–২৭ নভে, D-20 → D-15) — ৬ দিন
```
প্রতিদিন ৩.৫ ঘণ্টা:
  · ৪৫ মিনিট: SET-A / SET-B থেকে ৬০ MCQ (৪৫ সেকেন্ড/প্রশ্ন, timer)
  · ৪৫ মিনিট: লিখিত drill — ৪টি লিখিত প্রশ্ন (master-set-written-drill.csv)
  · ৩০ মিনিট: Anki (anki-deck.tsv) ৬০ card
  · ৩০ মিনিট: error log ও formula cards review
```
**এই ৬ দিনে তোমার written দক্ষতা তৈরি হবে — এটাই সবচেয়ে বড় ফায়ার।**

---

### PHASE 3 · PAPER-FINAL → SUBJECT-FINAL (২৮ নভে → ১ ডিসে, D-14 → D-11) — ৪ দিন
```
২৮ নভে  → 🎯 COACHING PAPER FINAL (তোমার baseline)
          সন্ধ্যায়: score + chapter-wise analysis (নিচের ritual)
২৯ নভে  → Paper Final-এ হারানো TOP 3 chapter ঠিক করো (শুধু ওগুলো)
৩০ নভে  → SET-B (৬০) + ওই ৩টি chapter-এর গভীর drill
১ ডিসে  → 🎯 COACHING SUBJECT FINAL
          সন্ধ্যায়: analysis + সবচেয়ে দুর্বল ২টি subject-এ ২ দিন
```
**Paper Final ও Subject Final-এর analysis-ই তোমার আসল পরিকল্পনা।** এগুলো skip করলে পরের ৫টা mock-ও উপকার হবে না।

---

### PHASE 4 · MOCK MODE (২–৫ ডিসে, D-10 → D-7) — ৪ দিন
```
২ ডিসে   → 🎯 MODEL TEST 1  (baseline — স্কোর কত হবে খেয়াল নেই, শুধু gap খুঁজো)
৩ ডিসে   → M1-এর সবচেয়ে কম ৩টি chapter ঠিক করো
৪ ডিসে   → 🎯 MODEL TEST 2
৫ ডিসে   → SET-C (wildcard, অন্য varsity-র material) + M2 analysis
```

---

### 🎯 ৫টি MODEL TEST-এর ল্যাডার

| Mock | টার্গেট স্কোর | কী মাপবে | কী করবে |
|---|---|---|---|
| **M1** | যা হয় (৫০-৬০) | chapter-এ কত নম্বর হারালো | TOP 5 lossy chapter ঠিক করো |
| **M2** | ৬০-৬৫ | MCQ accuracy vs written | যেখানে বেশি কম, সেটায় ভারী |
| **M3** | ৬৮-৭২ | সময় ব্যবহার — MCQ শেষ হয় কিনা ৪৫ মিনিটে | সময় বাস্তবসম্মত করো |
| **M4** | ৭২-৭৬ | written-এ partial credit নেওয়ার হার | written লেখার কৌশল শক্ত করো |
| **M5** | **৭৮-৮০** | পুরো paper | ★ EXAM-DAY TARGET পৌঁছেছো কিনা |

---

### PHASE 5 · MAT SHIFT (৫–৮ ডিসে, D-7 → D-4) — ৪ দিন
```
৫ ডিসে   → 🎯 MODEL TEST 3  (M3-এর gap ঠিক করার পর)
৬-৭ ডিসে → MAT SET-A (১০০ প্রশ্ন) — English ১৫ + GK ১০ এই দুই তোমার দুর্বলতা হবে
৮ ডিসে   → 🎯 MODEL TEST 4 + MAT-specific দুর্বলতা
```
⚠️ **DU Ka-র পরে ৬ দিন MAT-এর জন্য।** DU Ka-তে Bangla/English/ICT ছিল না (তুমি Math+Bio নিয়েছ), কিন্তু MAT-এ **English ১৫ + GK ১০ = ২৫ নম্বর** এসব থেকেই। তোমার ব্যাংকে English ৫১, GK ৫১ unique — **MAT-এর এই ২৫ নম্বরের জন্য এই ৬ দিনটাই তোমার সবচেয়ে দুর্বল জায়গা।** আগে থেকেই প্রস্তুত না হলে এখানেই ১০-১৫ নম্বর হারাবে।

---

### PHASE 6 · FINAL (৯–১১ ডিসে, D-3 → D-1) — ৩ দিন
```
৯ ডিসে   → 🎯 MODEL TEST 5 (মূল্যায়ন করো না — শুধু আত্মবিশ্বাস)
১০ ডিসে  → 🚫 নতুন কিছু নয়। শুধু error log + ৩৬৬ formula card
১১ ডিসে  → 🚫 নতুন কিছু নয়। হালকা পড়া। ঘুম ৫-৬ ঘণ্টা
১২ ডিসে  → ★★★ DU KA EXAM (১১:০০–১২:৩০)
```

---

## 🎯 COACHING EXAM-এর রিচুয়াল (প্রতিটিতে একই — এটাই আসল পরিকল্পনা)

**Paper Final, Subject Final, M1-M5 — প্রত্যেকটার পরে এই ৩ ধাপ, কোনোটাই বাদ দেওয়া যাবে না:**

```
① SCORE (৩০ মিনিট) — আসল পরীক্ষার নিয়মে
   MCQ: সঠিক − ভুল × 0.25     Written: আংশিক নম্বর (২-৫ নম্বরের প্রশ্ন)
   ১৫ নম্বরের subject-এ কত পেলে সেটা হিসেব করো

② CHAPTER-WISE LOSS ANALYSIS (২০ মিনিট)
   কোন chapter-এ কত নম্বর হারালো → TOP 3 lossy chapter বের করো
   (master-set-chapter-map.csv-এর chapter নাম মিলিয়ে)

③ FIX (পরবর্তী ৪৮ ঘণ্টায়)
   শুধু ওই TOP 3 chapter। বাকি সব সময় নষ্ট নয়।
```

**এটাই তোমার সবচেয়ে বড় সম্পদ তৈরি করবে — ৭টা coaching exam × ৭টি chapter analysis = তোমার নিজস্ব "error log dataset"।**

---

## ⚡ NON-NEGOTIABLE RULES

1. **MCQ-তে যা জানো না, ফাঁকা রাখো।** EV = 1.25P − 0.25 → **P > 20% হলে attempt করো**, তার কম হলে বাদ দাও। ২০% confident হলেও attempt করো (৫টা প্রশ্নে ১টা ভুল মানে −0.25, কিন্তু বাদ দিলে ০)।
2. **MCQ: ৪৫ সেকেন্ড/প্রশ্ন।** ৬০ প্রশ্ন × ৪৫ সে = ৪৫ মিনিট। Timer ছাড়া কখনো mock দিও না।
3. **Written কখনো skip করো না।** Partial credit আছে, −0.25 নেই। খালি রাখলে নিশ্চিত ০।
4. **Written-এ সিলেবাস স্টাইলে লেখো:** সূত্র → কাজ → উত্তর। প্রশ্নে যা চাইছে ঠিক সেটা।
5. **কোনো mock-এর পরে সাথে সাথে analysis করো**, পরের দিনে নয় — মেমরি ফ্রেশ থাকে না।
6. **M3-এর পরে নতুন content নেই।** শুধু error log।
7. **ক্যালকুলেটর নেই, ফোন নেই** — mock-এর সময়েও।

---

## ✍️ WRITTED-এর ৪০ নম্বর — আলাদা করে প্ল্যান (এটাই ভিন্নিয়েটর)

```
DU Ka written: 45 মিনিট, ৪টি বিষয় × ১০ নম্বর ≈ ১২টি প্রশ্ন (প্রতিটি ২-৫ নম্বর)
MAT-এ written নেই — তাই MAT-এ সব MCQ

সময় ভাগ (45 মিনিট):
  ০–৩০ মিনিট → সবচেয়ে সহজ ৮-৯ প্রশ্ন (প্রতি ৩ মিনিট)
  ৩০–৪২ মিনিট → ২-৩টি কঠিন প্রশ্ন (প্রতি ৪ মিনিট)
  ৪২–৪৫ মিনিট → ফিরে গিয়ে যা বাকি লিখতে পারো সেটা লেখো
```

**প্রতিদিন ৪টি লিখিত প্রশ্ন × ৩০ মিনিট — Phase 2 থেকে শুরু, কখনো ছাড়া নয়।** তোমার ব্যাংকে ১৬টি লিখিত আছে (সবই Week 09-এর) + ৩৬৬টি সূত্র কার্ড → এগুলোই যথেষ্ট ভিত্তি।

**কমপক্ষে ২৮/৪০ না পেলে ৭৮ আসবে না** (MCQ-তে −0.25 থাকায় ৫২/৬০ পেতে ≈৮৮% accuracy লাগবে)।

---

## 🎪 EXAM HALL TACTICS (১২ ডিসে, ১১:০০–১২:৩০)

```
১১:০০–১১:৪৫  MCQ (৬০ প্রশ্ন)
   · প্রথম ২০ মিনিটে সহজগুলো ধরো (তোমার SET-A-র মতো)
   · প্রতিটি ৪৫ সেকেন্ড — ঘণ্টা না দেখে চলো
   · ৩০ মিনিটে ৪০টা হলে ভালো pace
   · শেষ ১০ মিনিট: বাকিগুলো mark করো, যেগুলোতে ২০%+ sure সেগুলো বসাও
   · ✅ MCQ শেষ হলেই কলম রাখো — written-এর জন্য ৪৫ মিনিট আছে

১১:৪৫–১২:৩০  WRITTEN (৪০ নম্বর, ১২টি প্রশ্ন)
   · ৩০ মিনিটে ৮-৯টি সহজ প্রশ্ন শেষ করো (যেগুলোতে সিলেবাস মনে আছে)
   · পরে কঠিনগুলোতে সূত্র লেখো — partial credit পেতে হলে সূত্রটাই যথেষ্ট
   · ৩ মিনিটে একটা প্রশ্ন আটকে গেলে পরেরটায় চলে যাও
```

---

## 📋 MOCK TRACKER (প্রতিটি mock-এর পরে ফিল করো)

| কলাম | কী লিখবে |
|---|---|
| date | মোকের তারিখ |
| name | Paper Final / Subject Final / M1..M5 |
| Physics_MCQ, Physics_Written | (১৫ + ১০) |
| Chem_MCQ, Chem_Written | |
| Math_MCQ, Math_Written | |
| Bio_MCQ, Bio_Written | |
| MCQ_total, Written_total, GRAND_TOTAL | −0.25 সহ |
| accuracy_% | MCQ accuracy |
| time_MCQ_used | কত মিনিটে শেষ (৪৫-এর মধ্যে?) |
| time_written_used | ৪৫-এর মধ্যে? |
| top3_lossy_chapter | এই মোকে সবচেয়ে বেশি নম্বর হারানো ৩টি chapter |
| next48h_fix | ওই ৩টির জন্য কী করবে |
| written_blank_count | কতটি লিখিত ফাঁকা রেখেছ |

**CSV টেমপ্লেট: `mock-tracker.csv` · Error log: `error-log-template.csv`**

---

## 🎯 এখনই করো (আজ, ৩০ মিনিট)

1. **অ্যাপ freeze** — নতুন কোড শূন্য
2. **`20-80-FOCUS-only.csv` ছাপে রাখো** — এটাই তোমার পড়ার তালিকা
3. **`mock-tracker.csv` আর `error-log-template.csv` Google Sheet-এ খোলো**
4. **আজকে ২টি focus chapter + SET-A-র ঐ ২টি chapter-এর প্রশ্ন** — শুরু

---

## ❌ যা করবে না (২৫ দিনে)

- ❌ নতুন feature / নতুন UI / কোড (একটাও লাইন)
- ❌ অ্যাপের "98%/99% Predict Repeat" label-এ trust (editorial; আসল signal = year-frequency + তোমার নিজের mock score)
- ❌ নতুন কনটেন্ট M3-এর পরে
- ❌ MCQ-তে timer ছাড়া অনুশীলন
- ❌ Written প্রশ্ন skip
- ❌ mock-এর analysis বাদ দেওয়া

---

## শেষ কথা

**তোমার coaching-এর ৫টা model test-ই তোমার সবচেয়ে মূল্যবান predictor** — কারণ সেগুলো আসল DU/MAT pattern-এ সাজানো, তোমার ব্যাংকের master set-এর চেয়ে কাছাকাছি। তাই:

> **Master set = gap-filler (coaching exam-এর মাঝে)**
> **Model test = আসল predictor (coaching exam-এর সময়)**

এই দুটো আলাদা জায়গায় ব্যবহার করো। coaching exam-এর আগে master set দিয়ে দরজা খোলো, coaching exam-এ গিয়ে আসল প্রশ্ন দেখো, তারপর সেই analysis দিয়ে master set-এর ফাঁকগুলো বন্ধ করো — এটাই তোমার ২৫ দিনের লুপ।
