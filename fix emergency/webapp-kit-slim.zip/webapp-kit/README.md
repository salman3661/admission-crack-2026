# WEBAPP KIT — Admission Crack 2026 পুনর্গঠনের সম্পূর্ণ স্পেক

> তোমার অ্যাপটা এখন কাজ করে, কিন্তু ২৭ MB বান্ডিল, ভুল সংখ্যা, আর AI-generated প্রশ্নের ঝুঁকি আছে।
> এই kit-এ একটাই মাস্টার প্রম্পট + সব স্পেক + সব ফাইল আছে — যা একটি AI coding agent-কে দিলেই সে পুরোটা করতে পারবে।

---

## 🚀 কীভাবে ব্যবহার করবে

```
১. docs/00-MASTER-PROMPT.md  →  পুরোটা একটি AI coding agent-কে দাও
                               (Claude Code / Cursor / Windsurf / Codex)
২. এই kit-টা agent-কে দাও (repo-তে রাখো বা zip করে)
৩. Agent কাজ শুরু করবে → Phase অনুযায়ী → শেষে REPORT.md-তে প্রমাণ দেবে
```

### Coaching-এর নতুন প্রশ্ন কোথায় দেবে
```
src/data/du_ka/model_test/model_test_03.json
src/data/du_ka/paper_final/paper_final_01.json
src/data/du_ka/weekly_solve/week_03.json
src/data/mat/model_test/mat_model_test_01.json
```
Format: `docs/01-DATA-SCHEMA.md` দেখো। প্রতিটি প্রশ্নে `source_type` আর `exam_date` **আবশ্যক** — predictor এগুলো দিয়েই coaching paper-কে বেশি ওজন দেয়।

---

## 📁 Kit-এর গঠন

```
webapp-kit/
├── README.md                          ← এই ফাইল
├── docs/
│   ├── 00-MASTER-PROMPT.md            ★ agent-কে দেওয়ার মূল প্রম্পট
│   ├── 01-DATA-SCHEMA.md              schema + tagging rule
│   ├── 02-ENGINEERING-RULES.md        ১৫টি rule, প্রতিটির কারণ + performance target
│   ├── 03-PREDICTOR-SPEC.md           LEARN→PREDICT→SELECT + validation
│   ├── 04-FEATURES-SCOPE.md           F1–F16, P0/P1/P2 ভাগ
│   └── 05-ACCEPTANCE-CRITERIA.md      যাচাইয়ের পুরো checklist
├── data/
│   ├── bank/                          ৫৫টি split ফাইল (regenerable, .gitignore-এ)
│   ├── chapter-taxonomy.csv           ৬৪টি chapter: slug + readable নাম + বছর + source
│   ├── sample-question.json           ৫টি example row (একটি written সহ)
│   ├── mock-tracker-template.csv      mock tracker-এর কলাম
│   └── master/                        generated: set_a / set_b / set_c × du_ka / mat
└── scripts/
    ├── prepare-data.mjs               bundle → normalized bank + taxonomy
    ├── validate-data.mjs              CI data-lint
    ├── build-master-set.mjs           master set + chapter map তৈরি
    └── coverage-scorer.mjs            যেকোনো প্রশ্ন-সেট score করা
```

---

## 🔧 স্ক্রিপ্টগুলো (standalone চলে)

```bash
node scripts/prepare-data.mjs      # deployed bundle → normalized bank + taxonomy
node scripts/validate-data.mjs data/bank-normalized.json
node scripts/build-master-set.mjs  # master set + chapter map
node scripts/coverage-scorer.js candidates.json
```
প্রতিটি স্ক্রিপ্ট প্রথমবার ব্যাংক না থাকলে **নিজে থেকেই** deployed bundle থেকে টেনে নেয় — কোনো setup লাগে না।

### এখনকার অবস্থা (validate করলে যা দেখাবে)
```
ℹ️  1 ফাইল, 1442 প্রশ্ন
── WARN (গ্রুপ করা) ──
  ⚠ exam_year নেই                                            ×796
  ⚠ একই প্রশ্ন আরেক জায়গায় — appears_in merge করো          ×148
  ⚠ answer bias A = 38.1% — অপশন shuffle ব্যবহার করো
  ⚠ answer bias B = 35.1% — অপশন shuffle ব্যবহার করো
  ⚠ answer bias D = 8.6%  — অপশন shuffle ব্যবহার করো
0 error, 947 warning
```
**এই ৪টা warning-ই agent-এর কাজের তালিকা।** coaching paper যোগ করার সাথে সাথে `exam_year` ও `appears_in` সমস্যাগুলো এলোমেলো করে যাবে।

---

## 🎯 Master Set (script দিয়ে তৈরি, যাচাই করা)

```
DU Ka A   60 প্রশ্ন | 16 chapter | MAT A  100 প্রশ্ন | 27 chapter
DU Ka B   60 প্রশ্ন | 16 chapter | MAT B  100 প্রশ্ন | 25 chapter
DU Ka C   21 (wildcard)            MAT C  31 (wildcard)
```
`data/master-set-chapter-map.csv`-এ প্রতিটি chapter-এর predicted %, expected MCQ, years_hit, papers_hit, কোন set-এ কয়টি।

**`source_type` weight কেন আলাদা:**
```
model_test 1.00 > paper_final 0.95 > subject_final 0.90 > past_paper 0.85 > weekly_solve 0.70
```
Coaching-এর Model Test আসল exam-pattern paper — তাই এগুলো predictor-কে সবচেয়ে বেশি শেখায়। **এগুলো ঢোকানোর পরে backtest-এর coverage সংখ্যা বাড়বে**, আর সেটাই তোমার predictor-এর সত্যিকারের প্রমাণ।

---

## 📌 সবচেয়ে গুরুত্বপূর্ণ ৫টি কথা

1. **AI প্রশ্ন বানাবে না** — তোমার আসল bank থেকে select করবে। কোনোটাই fake হবে না।
2. **প্রতিটি সংখ্যা runtime-এ গণনা হবে** — "১,৩৪৭ প্রেডিক্টর" টাইপের হাত-লেখা সংখ্যা থাকবে না।
3. **Model Test = held-out validation set** — coaching-এর Model Test আসল pattern, তাই সেটা দিয়ে তোমার predictor-এর সত্যিকারের accuracy মাপা যাবে। **এটাই সবচেয়ে মূল্যবান সংখ্যা।**
4. **Written-এর ৪০ নম্বরই আসল differentiator** — MCQ-তে −0.25 আছে, written-এ নেই। ওইটা ভালোভাবে করতে না পারলে ৭৮ আসবে না।
5. **বাংলা UI copy আর ডিজাইন অপরিবর্তিত থাকবে** — শুধু structure আর logic বদলাবে।

---

## 📦 ফাইল সাইজের সমস্যা ও সমাধান

ব্যাংক normalized করে ২.৪ MB হয় — কিন্তু **তোমাকে ওটা upload করতে হবে না।**

| ফাইল | সাইজ | কখন দরকার |
|---|---|---|
| `webapp-kit-slim.zip` | **৫৮ KB** | ★ agent-কে এটুকুই দাও — docs + scripts + templates |
| `webapp-kit-data.zip` | ৪১৪ KB | শুধু তখন দরকার যখন agent-কে existing data দেখাতে চাও (৫৫টি split ফাইল, সবচেয়ে বড় ৩০৪ KB) |
| `data/bank-normalized.json.gz` | ৩৪৮ KB | single-file হিসেবে দরকার হলে (gzip) |

**Agent যেভাবে data পাবে (তোমার কোনো upload লাগবে না):**
```bash
node scripts/prepare-data.mjs
   → deployed bundle থেকে নিজে থেকেই bank টেনে নেয়
   → data/bank/<exam>/<source_type>/<subject>.json  (৫৫টি ছোট ফাইল)
   → data/chapter-taxonomy.csv + data/sample-question.json
node scripts/build-master-set.mjs   → master set তৈরি
```
`.gitignore`-এ `data/bank/`, `data/master/`, `scripts/.bankcache` আছে — এগুলো regenerable, commit করো না।

**Size কেন বড়:** মোট content ১,৪৪২ প্রশ্ন × (প্রশ্ন + ৪টি অপশন + ব্যাখ্যা + ট্র্যাপ) — বাংলা UTF-8-তে ৩ বাইট/অক্ষর, LaTeX-ও আছে। Pretty-print বাদ দিলেও ২.২ MB-ই থাকে। **তাই split-ই সঠিক সমাধান** — এটা মাস্টার প্রম্পটের চাওয়া architecture-ই (`src/data/<exam>/<source_type>/<subject>.json`)।

---

## 🔄 নতুন paper যোগ করার ৪ ধাপ

```
১. src/data/<exam>/<source_type>/<name>.json  ফাইল বানাও (schema অনুযায়ী)
২. node scripts/validate-data.mjs src/data     → 0 error নিশ্চিত করো
৩. node scripts/build-master-set.mjs            → master set আবার তৈরি
৪. node scripts/coverage-scorer.js <set.json>  → সব REAL-PAST কিনা দেখো
```

| `docs/06-NEW-FEATURES.md` | ★ **ROUND 2** — ডেটা ফিক্স (A1-A4) + ৫টি নতুন ফিচার (F17-F21) + acceptance criteria |
| `scripts/extract-formulas.mjs` | ব্যাংকের explanation/trap থেকে সূত্র বের করে chapter-centric সূত্র-কার্ড ডেটা বানায় |
